import React from 'react';
import TicTacToe from './TicTacToe';

function App() {
  return (
    <div className="App">
      <TicTacToe />
    </div>
  );
}

export default App;